  <div class="about">
    <div class="heading">About</div>
    <p>
      <span class="label">Bio</span><br>
      Digital designer and art director with 7 years experience producing concepts, screen design, digital products and live experiences for major national and global brands.
    </p>
    <p>
      <span class="label">Clients</span><br>
      PWC Audi Telstra Google Pernod Ricard Suncorp Caltex Coca Cola Reckitt Benckiser Village Roadshow Event QT
    </p>
    <p>
      <span class="label">Contact</span><br>
      <a href="mailto:grce.goran@gmail.com">@</a>
    </p>
  </div>

</div>

</div>


</body>
</html>
